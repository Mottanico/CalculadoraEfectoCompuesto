let P = prompt("capital inicial");
let r = prompt("ingresa la tasa de interes anual");
let Y = prompt("ingresa los años");
let n = prompt("Ingresa adicion mensual");
const FV = P (1 + r / n)**Y*n;
alert(`El resultado de ${Y} meses es: ${FV}`)